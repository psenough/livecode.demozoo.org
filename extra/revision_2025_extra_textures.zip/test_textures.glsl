#version 420 core

uniform float fGlobalTime; // in seconds
uniform vec2 v2Resolution; // viewport resolution (in pixels)
uniform float fFrameTime; // duration of the last frame, in seconds

uniform sampler1D texFFT; // towards 0.0 is bass / lower freq, towards 1.0 is higher / treble freq
uniform sampler1D texFFTSmoothed; // this one has longer falloff and less harsh transients
uniform sampler1D texFFTIntegrated; // this is continually increasing
uniform sampler2D texPreviousFrame; // screenshot of the previous frame
uniform sampler2D texAcorn1;
uniform sampler2D texAcorn2;
uniform sampler2D texChecker;
uniform sampler2D texLeafs;
uniform sampler2D texNoise;
uniform sampler2D texRevisionBW;
uniform sampler2D texTex1;
uniform sampler2D texTex2;
uniform sampler2D texTex3;
uniform sampler2D texTex4;
uniform sampler2D texLynn;
layout(location = 0) out vec4 out_color; // out_color must be written in order to see anything


vec4 txt(vec2 p){
    
    float t= mod(floor(fGlobalTime),5);
    if(t<1){
      return texture(texAcorn1,clamp(p*vec2(1,-1),-.5,.5)-.5);
    }
     if(t<2){
      return texture(texAcorn2,clamp(p*vec2(1,-1),-.5,.5)-.5);
    }
    if(t<3){
      return texture(texLeafs,clamp(p*vec2(1,-1),-.5,.5)-.5);
    }
    if(t<4){
      return texture(texRevisionBW,clamp(p*vec2(1,-1),-.5,.5)-.5);
    }  
    if(t<5){
      return texture(texLynn,clamp(p*vec2(1,-1),-.5,.5)-.5);
    }   
      
  }
void main(void)
{
	vec2 uv = vec2(gl_FragCoord.x / v2Resolution.x, gl_FragCoord.y / v2Resolution.y);
	uv -= 0.5;
	uv /= vec2(v2Resolution.y / v2Resolution.x, 1);

 vec3 col = 1-sqrt(length(uv))+vec3(0.);
  vec4 t = txt(uv*(2-exp(-3*fract(fGlobalTime))));
  col =mix(col,sqrt(t.rgb),uv.x< 0 ? t.a:1);
	out_color = vec4(col,1.);
}